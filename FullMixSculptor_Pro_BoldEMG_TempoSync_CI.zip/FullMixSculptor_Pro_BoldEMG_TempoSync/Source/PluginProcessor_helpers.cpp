#include "PluginProcessor.h"

void FullMixSculptorProAudioProcessor::getStateInformation (juce::MemoryBlock& destData)
{ juce::MemoryOutputStream os(destData,true); apvts.state.writeToStream(os); }

void FullMixSculptorProAudioProcessor::setStateInformation (const void* d, int sz)
{ if(auto v=juce::ValueTree::readFromData(d,sz)) apvts.replaceState(v); }

void FullMixSculptorProAudioProcessor::applyProfile (int idx)
{
    auto pr = PresetProfiles::get(idx);
    apvts.getParameter("tilt")->setValueNotifyingHost(apvts.getParameterRange("tilt").convertTo0to1(pr.tilt));
    apvts.getParameter("glue")->setValueNotifyingHost(apvts.getParameterRange("glue").convertTo0to1(pr.glue));
    apvts.getParameter("width")->setValueNotifyingHost(apvts.getParameterRange("width").convertTo0to1(pr.width));
    apvts.getParameter("sat")->setValueNotifyingHost(apvts.getParameterRange("sat").convertTo0to1(pr.sat));
    apvts.getParameter("dynTilt")->setValueNotifyingHost(apvts.getParameterRange("dynTilt").convertTo0to1(pr.dynTilt));
    apvts.getParameter("ceiling")->setValueNotifyingHost(apvts.getParameterRange("ceiling").convertTo0to1(pr.ceiling));
}

void FullMixSculptorProAudioProcessor::updateFilters()
{
    const float t = apvts.getRawParameterValue("tilt")->load();
    const double sr = spec.sampleRate>0? spec.sampleRate:44100.0;
    const float g = juce::jlimit(-6.0f,6.0f, t*6.0f/3.0f);
    *tiltLow.state  = *juce::dsp::IIR::Coefficients<float>::makeLowShelf((float)sr, 650.0f, 0.707f, juce::Decibels::decibelsToGain(g));
    *tiltHigh.state = *juce::dsp::IIR::Coefficients<float>::makeHighShelf((float)sr, 650.0f, 0.707f, juce::Decibels::decibelsToGain(-g));
}

void FullMixSculptorProAudioProcessor::updateCompressor()
{
    const float g = apvts.getRawParameterValue("glue")->load();
    glueComp.setAttack(juce::jmap(g,30.0f,5.0f));
    glueComp.setRelease(juce::jmap(g,200.0f,80.0f));
    glueComp.setRatio(juce::jmap(g,1.2f,3.0f));
    glueComp.setThreshold(juce::jmap(g,0.0f,-12.0f));
}

void FullMixSculptorProAudioProcessor::updateSaturator()
{
    const float s = apvts.getRawParameterValue("sat")->load();
    saturator.functionToUse = [drive=juce::jmap(s,0.0f,0.9f)](float x){ return std::tanh(drive*x); };
}

void FullMixSculptorProAudioProcessor::updateLimiter()
{
    const float c = apvts.getRawParameterValue("ceiling")->load();
    limiter.setRelease(50.0f); limiter.setThreshold(c);
}

void FullMixSculptorProAudioProcessor::applyDynamicTilt()
{
    float dyn = apvts.getRawParameterValue("dynTilt")->load();
    if(dyn<=0.001f) return;
    float lufs = meter.getMomentaryLUFS();
    float adjust = juce::jlimit(-0.5f,0.5f, juce::jmap(lufs,-30.0f,-10.0f,-0.2f,0.2f));
    auto* pTilt = apvts.getParameter("tilt");
    float cur = apvts.getRawParameterValue("tilt")->load();
    float tgt = cur + dyn*adjust;
    pTilt->setValueNotifyingHost(apvts.getParameterRange("tilt").convertTo0to1(tgt));
}

double FullMixSculptorProAudioProcessor::getHostBPM() const
{
    if(auto* ph=getPlayHead()){ juce::AudioPlayHead::CurrentPositionInfo pos; if(ph->getCurrentPosition(pos) && pos.bpm>0.0) return pos.bpm; }
    return 120.0;
}

bool FullMixSculptorProAudioProcessor::auditionIndex (int idx, bool loop)
{
    if(idx<0 || idx>=currentSuggestions.size()) return false;
    juce::File f(currentSuggestions[idx]);
    if(!f.existsAsFile()) return false;
    if(auditioner.loadFile(f, loop)){ auditioner.start(); return true; }
    return false;
}

bool FullMixSculptorProAudioProcessor::autoChopIndexToLoop (int idx)
{
    if(idx<0 || idx>=currentSuggestions.size()) return false;
    juce::File f(currentSuggestions[idx]);
    if(!f.existsAsFile()) return false;
    auto res = chopper.makeLoopFromFile(f,4,1.5f,true);
    apvts.getParameter("lastLoopBPM")->setValueNotifyingHost(apvts.getParameterRange("lastLoopBPM").convertTo0to1((float)res.estimatedBPM));
    auto dir = juce::File(res.exportFolder);
    auto loop = dir.getChildFile(f.getFileNameWithoutExtension()+"_loop.wav");
    if(loop.existsAsFile()){ if(auditioner.loadFile(loop,true)){ auditioner.start(); return true; } }
    return false;
}
