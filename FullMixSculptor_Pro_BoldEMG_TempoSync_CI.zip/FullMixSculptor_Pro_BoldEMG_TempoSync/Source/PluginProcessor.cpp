#include "PluginProcessor.h"
#include "PluginEditor.h"

static inline float dBToLinear (float db) { return juce::Decibels::decibelsToGain (db); }

FullMixSculptorProAudioProcessor::FullMixSculptorProAudioProcessor()
: juce::AudioProcessor (BusesProperties().withInput("In", juce::AudioChannelSet::stereo(), true)
                                         .withOutput("Out", juce::AudioChannelSet::stereo(), true)) {}

void FullMixSculptorProAudioProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    spec = { sampleRate, (juce::uint32) samplesPerBlock, 2 };
    oversample.reset (new juce::dsp::Oversampling<float>(2, 1, juce::dsp::Oversampling<float>::filterHalfBandPolyphaseIIR, true));
    tiltLow.prepare(spec); tiltHigh.prepare(spec); glueComp.prepare(spec); saturator.prepare(spec); limiter.prepare(spec);
    meter.prepare (sampleRate, samplesPerBlock); auditioner.prepare (sampleRate, samplesPerBlock); chopper.prepare (sampleRate); library.load();
    updateFilters(); updateCompressor(); updateSaturator(); updateLimiter();
}

bool FullMixSculptorProAudioProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    const auto& i = layouts.getChannelSet(true,0); const auto& o = layouts.getChannelSet(false,0);
    return i == o && (i == juce::AudioChannelSet::mono() || i == juce::AudioChannelSet::stereo());
}

void FullMixSculptorProAudioProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midi)
{
    juce::ignoreUnused(midi);
    applyProfile ((int) apvts.getRawParameterValue("profile")->load());
    applyDynamicTilt(); updateFilters(); updateCompressor(); updateSaturator(); updateLimiter();

    auto blk = juce::dsp::AudioBlock<float>(buffer); auto os = oversample->processSamplesUp (blk);
    juce::dsp::ProcessContextReplacing<float> ctx (os);
    tiltLow.process(ctx); tiltHigh.process(ctx); glueComp.process(ctx); saturator.process(ctx); limiter.process(ctx);
    oversample->processSamplesDown (blk);

    meter.process(buffer);
    suggester.pushAudio(buffer, (float) getSampleRate());

    double hostBPM = getHostBPM();
    double sourceBPM = apvts.getRawParameterValue("lastLoopBPM")->load();
    auditioner.setTempoSync (sourceBPM, hostBPM);
    auditioner.getNextBlock (buffer, buffer.getNumSamples());
}

juce::AudioProcessorValueTreeState::ParameterLayout FullMixSculptorProAudioProcessor::createParameterLayout()
{
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> p;
    p.push_back (std::make_unique<juce::AudioParameterChoice>("profile","Style Profile",
        juce::StringArray{ "Neutral","R&B Smooth","Trap Punch","LoFi Chill","Punchy Trap 808","Warm BoomBap","Club Banger Shine","Dark Drill","Just Blaze-Style Chop","Jaycen-Style","Serban-Style","Leslie-Style"}, 0));
    p.push_back (std::make_unique<juce::AudioParameterFloat>("tilt","Tone Tilt", juce::NormalisableRange<float>(-3.0f,3.0f,0.01f),0.0f));
    p.push_back (std::make_unique<juce::AudioParameterFloat>("glue","Glue", juce::NormalisableRange<float>(0.0f,1.0f,0.001f),0.3f));
    p.push_back (std::make_unique<juce::AudioParameterFloat>("width","Width", juce::NormalisableRange<float>(0.0f,2.0f,0.001f),1.0f));
    p.push_back (std::make_unique<juce::AudioParameterFloat>("sat","Sweetener", juce::NormalisableRange<float>(0.0f,1.0f,0.001f),0.1f));
    p.push_back (std::make_unique<juce::AudioParameterFloat>("dynTilt","Dynamic Tilt", juce::NormalisableRange<float>(0.0f,1.0f,0.001f),0.2f));
    p.push_back (std::make_unique<juce::AudioParameterFloat>("ceiling","Ceiling (dB)", juce::NormalisableRange<float>(-6.0f,-0.1f,0.01f),-1.0f));
    p.push_back (std::make_unique<juce::AudioParameterBool>("assist_loops","Include Loops", true));
    p.push_back (std::make_unique<juce::AudioParameterFloat>("auditionGain","Audition Gain", juce::NormalisableRange<float>(0.0f,2.0f,0.01f),0.8f));
    p.push_back (std::make_unique<juce::AudioParameterFloat>("lastLoopBPM","Last Loop BPM", juce::NormalisableRange<float>(40.0f,220.0f,0.01f),120.0f));
    return { p.begin(), p.end() };
}

void FullMixSculptorProAudioProcessor::applyProfile (int idx)
{
    auto pr = PresetProfiles::get (idx);
    apvts.getParameter("tilt")->setValueNotifyingHost(apvts.getParameterRange("tilt").convertTo0to1(pr.tilt));
    apvts.getParameter("glue")->setValueNotifyingHost(apvts.getParameterRange("glue").convertTo0to1(pr.glue));
    apvts.getParameter("width")->setValueNotifyingHost(apvts.getParameterRange("width").convertTo0to1(pr.width));
    apvts.getParameter("sat")->setValueNotifyingHost(apvts.getParameterRange("sat").convertTo0to1(pr.sat));
    apvts.getParameter("dynTilt")->setValueNotifyingHost(apvts.getParameterRange("dynTilt").convertTo0to1(pr.dynTilt));
    apvts.getParameter("ceiling")->setValueNotifyingHost(apvts.getParameterRange("ceiling").convertTo0to1(pr.ceiling));
}

void FullMixSculptorProAudioProcessor::updateFilters()
{
    const float t = apvts.getRawParameterValue("tilt")->load();
    const double sr = spec.sampleRate>0? spec.sampleRate:44100.0;
    const float g = juce::jlimit(-6.0f,6.0f, t*6.0f/3.0f);
    *tiltLow.state  = *juce::dsp::IIR::Coefficients<float>::makeLowShelf((float)sr, 650.0f, 0.707f, juce::Decibels::decibelsToGain(g));
    *tiltHigh.state = *juce::dsp::IIR::Coefficients<float>::makeHighShelf((float)sr, 650.0f, 0.707f, juce::Decibels::decibelsToGain(-g));
}

void FullMixSculptorProAudioProcessor::updateCompressor()
{
    const float g = apvts.getRawParameterValue("glue")->load();
    glueComp.setAttack(juce::jmap(g,30.0f,5.0f));
    glueComp.setRelease(juce::jmap(g,200.0f,80.0f));
    glueComp.setRatio(juce::jmap(g,1.2f,3.0f));
    glueComp.setThreshold(juce::jmap(g,0.0f,-12.0f));
}

void FullMixSculptorProAudioProcessor::updateSaturator()
{
    const float s = apvts.getRawParameterValue("sat")->load();
    saturator.functionToUse = [drive = juce::jmap (s, 0.0f, 0.9f)] (float x) { return std::tanh (drive * x); };
}

void FullMixSculptorProAudioProcessor::updateLimiter()
{
    const float c = apvts.getRawParameterValue("ceiling")->load();
    limiter.setRelease (50.0f); limiter.setThreshold (c);
}

void FullMixSculptorProAudioProcessor::applyDynamicTilt()
{
    float dyn = apvts.getRawParameterValue("dynTilt")->load(); if (dyn <= 0.001f) return;
    float adjust = 0.0f; // placeholder simple
    auto* p = apvts.getParameter("tilt"); float cur = apvts.getRawParameterValue("tilt")->load();
    p->setValueNotifyingHost(apvts.getParameterRange("tilt").convertTo0to1(cur + dyn * adjust));
}

double FullMixSculptorProAudioProcessor::getHostBPM() const
{
    if (auto* ph = getPlayHead()){ juce::AudioPlayHead::CurrentPositionInfo pos; if (ph->getCurrentPosition(pos) && pos.bpm>0.0) return pos.bpm; }
    return 120.0;
}

bool FullMixSculptorProAudioProcessor::auditionIndex(int idx, bool loop)
{
    if (idx < 0 || idx >= currentSuggestions.size()) return false;
    juce::File f(currentSuggestions[idx]); if(!f.existsAsFile()) return false;
    if (auditioner.loadFile(f, loop)) { auditioner.start(); return true; } return false;
}
bool FullMixSculptorProAudioProcessor::autoChopIndexToLoop(int idx)
{
    if (idx < 0 || idx >= currentSuggestions.size()) return false;
    juce::File f(currentSuggestions[idx]); if(!f.existsAsFile()) return false;
    auto res = chopper.makeLoopFromFile(f,4,1.5f,true);
    apvts.getParameter("lastLoopBPM")->setValueNotifyingHost(apvts.getParameterRange("lastLoopBPM").convertTo0to1((float)res.estimatedBPM));
    auto dir = juce::File(res.exportFolder); auto loop = dir.getChildFile(f.getFileNameWithoutExtension()+"_loop.wav");
    if(loop.existsAsFile()) { if (auditioner.loadFile(loop,true)) { auditioner.start(); return true; } }
    return false;
}

void FullMixSculptorProAudioProcessor::getStateInformation (juce::MemoryBlock& destData)
{ juce::MemoryOutputStream os(destData,true); apvts.state.writeToStream(os); }

void FullMixSculptorProAudioProcessor::setStateInformation (const void* data, int sizeInBytes)
{ if (auto v = juce::ValueTree::readFromData(data,sizeInBytes)) apvts.replaceState(v); }
