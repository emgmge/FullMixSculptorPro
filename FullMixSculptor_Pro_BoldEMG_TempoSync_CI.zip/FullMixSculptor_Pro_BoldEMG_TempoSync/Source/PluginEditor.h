#pragma once
#include <JuceHeader.h>
#include "PluginProcessor.h"
class FullMixSculptorProAudioProcessorEditor : public juce::AudioProcessorEditor, private juce::Timer
{
public:
    explicit FullMixSculptorProAudioProcessorEditor (FullMixSculptorProAudioProcessor&);
    void paint (juce::Graphics&) override;
    void resized() override;
private:
    FullMixSculptorProAudioProcessor& p;
    juce::ComboBox profile;
    juce::Slider tilt,glue,width,sat,dynTilt,ceiling,auditionGain;
    juce::ListBox list;
    juce::TextButton prevBtn{"Prev"}, nextBtn{"Next"}, playBtn{"Play"}, chopBtn{"Auto-Chop → Loop"}, keyBtn{"Detect Key"};
    juce::Label keyLabel;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> profileAtt;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> tiltAtt,glueAtt,widthAtt,satAtt,dynTiltAtt,ceilingAtt,audGainAtt;
    void refreshSuggestions();
    void timerCallback() override;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (FullMixSculptorProAudioProcessorEditor)
};
