#include "PluginEditor.h"

class SuggestModel : public juce::ListBoxModel
{
public:
    SuggestModel (juce::StringArray& d) : data(d) {}
    int getNumRows() override { return data.size(); }
    void paintListBoxItem (int row, juce::Graphics& g, int w, int h, bool sel) override
    {
        g.fillAll (sel ? juce::Colours::darkgrey : juce::Colours::black);
        g.setColour (juce::Colours::white);
        g.drawText (juce::File(data[row]).getFileName(), 4, 0, w-8, h, juce::Justification::centredLeft);
    }
    juce::StringArray& data;
};

FullMixSculptorProAudioProcessorEditor::FullMixSculptorProAudioProcessorEditor (FullMixSculptorProAudioProcessor& proc)
: AudioProcessorEditor (&proc), p(proc)
{
    setSize (820, 480);
    addAndMakeVisible (profile);
    profileAtt = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(p.apvts, "profile", profile);

    auto knob=[&](juce::Slider& s){ s.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag); s.setTextBoxStyle(juce::Slider::TextBoxBelow,true,56,18); };
    for(auto* s : {&tilt,&glue,&width,&sat,&dynTilt,&ceiling,&auditionGain}){ addAndMakeVisible(*s); knob(*s); }
    tiltAtt=std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(p.apvts,"tilt",tilt);
    glueAtt=std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(p.apvts,"glue",glue);
    widthAtt=std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(p.apvts,"width",width);
    satAtt=std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(p.apvts,"sat",sat);
    dynTiltAtt=std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(p.apvts,"dynTilt",dynTilt);
    ceilingAtt=std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(p.apvts,"ceiling",ceiling);
    audGainAtt=std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(p.apvts,"auditionGain",auditionGain);

    addAndMakeVisible (list);
    list.setModel (new SuggestModel (p.currentSuggestions));
    list.onDoubleClick = [this](int row){ if (row >= 0) p.auditionIndex(row,true); };

    addAndMakeVisible(prevBtn); addAndMakeVisible(nextBtn); addAndMakeVisible(playBtn); addAndMakeVisible(chopBtn);
    prevBtn.onClick=[this]{ int r=list.getSelectedRow()-1; if(r<0) r=list.getNumRows()-1; list.selectRow(r); p.auditionIndex(r,true); };
    nextBtn.onClick=[this]{ int r=(list.getSelectedRow()+1)%juce::jmax(1,list.getNumRows()); list.selectRow(r); p.auditionIndex(r,true); };
    playBtn.onClick=[this]{ int r=list.getSelectedRow(); if(r>=0) p.auditionIndex(r,true); };
    chopBtn.onClick=[this]{ int r=list.getSelectedRow(); if(r>=0) p.autoChopIndexToLoop(r); };

    addAndMakeVisible(keyBtn); addAndMakeVisible(keyLabel);
    keyBtn.onClick=[this]{ int r=list.getSelectedRow(); if(r<0) return; juce::File f(p.currentSuggestions[r]); juce::AudioFormatManager fm; fm.registerBasicFormats(); if(auto* rdr=fm.createReaderFor(f)){ std::unique_ptr<juce::AudioFormatReader> rr(rdr); juce::AudioBuffer<float> tmp((int)rr->numChannels,(int)rr->lengthInSamples); rr->read(&tmp,0,(int)rr->lengthInSamples,0,true,true); juce::AudioBuffer<float> mono(1,tmp.getNumSamples()); mono.clear(); for(int c=0;c<tmp.getNumChannels();++c) mono.addFrom(0,0,tmp,c,0,tmp.getNumSamples(),1.0f/tmp.getNumChannels()); auto k=p.keydet.detectKey(mono, rr->sampleRate); keyLabel.setText("Key: "+k, juce::dontSendNotification);} };

    startTimerHz(8);
}

void FullMixSculptorProAudioProcessorEditor::paint (juce::Graphics& g)
{
    g.fillAll (juce::Colour::fromRGB (10,10,12));
    g.setColour (juce::Colours::white);
    g.setFont (juce::Font (24.0f, juce::Font::bold));
    g.drawText ("EMG PRODUCTION STUDIOS", getLocalBounds().removeFromTop(30), juce::Justification::centredTop);
    g.setFont (16.0f);
    g.drawFittedText ("FullMix Sculptor Pro", {0,30,getWidth(),24}, juce::Justification::centredTop, 1);
}

void FullMixSculptorProAudioProcessorEditor::resized()
{
    auto a=getLocalBounds().reduced(10);
    a.removeFromTop(54);
    auto top=a.removeFromTop(28); profile.setBounds(top.removeFromLeft(260));
    auto knobs=a.removeFromTop(160); auto w=knobs.getWidth()/7;
    tilt.setBounds(knobs.removeFromLeft(w)); glue.setBounds(knobs.removeFromLeft(w)); width.setBounds(knobs.removeFromLeft(w));
    sat.setBounds(knobs.removeFromLeft(w)); dynTilt.setBounds(knobs.removeFromLeft(w)); ceiling.setBounds(knobs.removeFromLeft(w));
    auditionGain.setBounds(knobs.removeFromLeft(w));
    auto row=a.removeFromTop(28);
    prevBtn.setBounds(row.removeFromLeft(70)); playBtn.setBounds(row.removeFromLeft(70)); nextBtn.setBounds(row.removeFromLeft(70));
    chopBtn.setBounds(row.removeFromLeft(170)); keyBtn.setBounds(row.removeFromLeft(110)); keyLabel.setBounds(row);
    list.setBounds(a);
}

void FullMixSculptorProAudioProcessorEditor::refreshSuggestions()
{
    p.currentSuggestions = p.library.suggestList(p.suggester.getVibeText(), p.suggester.getEnergy(),
                                                 p.apvts.getRawParameterValue("assist_loops")->load() > 0.5f);
    list.updateContent();
    if(list.getNumRows()>0 && list.getSelectedRow()<0) list.selectRow(0);
}

void FullMixSculptorProAudioProcessorEditor::timerCallback()
{
    refreshSuggestions();
    repaint();
}
